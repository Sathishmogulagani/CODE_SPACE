--ctrl+shift+p-->palet
--ctrl+shift+Q-->to execute cmd

-- CREATE table "user_data" (
--     name TEXT,
--     phone TEXT,
--     gender TEXT,
--     age INT,
--     email_id TEXT,
--     address TEXT,
--     schedule TEXT,

--     slot_id INT,
--     time_stamp INT
-- );

-- insert into user_data values('name','ph','g',7,'mail','add','sdsd',1,10);
-- select * from user_data;
-- delete from user_data where time_stamp=10;
-- drop table user_data;
-- update user_data set time_stamp=22 where time_stamp=21;



-- CREATE table "walk_in" (
--     name TEXT,
--     phone TEXT,
--     gender TEXT,
--     age INT
-- );
-- insert into walk_in values('xyz','1234567890','m',21);
select * from walk_in;